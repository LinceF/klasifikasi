# Fruits Detection

- Preprocessed data. Trained and tested FasterRCNN, RetinaNet and SSD models. 
- Tested different inference configurations for object detection task.

![fruits](https://user-images.githubusercontent.com/71336130/157890301-34e63d79-2219-414a-a7aa-97480cf50198.png)
